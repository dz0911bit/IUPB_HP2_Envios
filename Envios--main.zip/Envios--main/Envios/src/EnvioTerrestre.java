public class EnvioTerrestre extends Envio {

    public EnvioTerrestre(String codigo, String cliente, double peso, double distancia) {
        super(codigo, cliente, peso, distancia);
    }

    @Override
    public double calcularCosto() {
        // Fórmula terrestre
        return 1500 * distancia + 2000 * peso;
    }
}
