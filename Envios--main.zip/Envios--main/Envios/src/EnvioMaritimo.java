public class EnvioMaritimo extends Envio {

    public EnvioMaritimo(String codigo, String cliente, double peso, double distancia) {
        super(codigo, cliente, peso, distancia);
    }

    @Override
    public double calcularCosto() {
        // Fórmula marítima
        return 800 * distancia + 1000 * peso;
    }
}
