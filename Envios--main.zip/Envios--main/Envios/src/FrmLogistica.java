import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.net.URL;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class FrmLogistica extends JFrame {

    // Mantengo el mismo orden de columnas que tenías originalmente
    public String[] encabezados = new String[] { "Código", "Cliente", "Peso", "Distancia", "Tipo", "Costo" };

    private JTable tblEnvios;
    private JPanel pnlEditarEnvio;

    private JTextField txtNumero, txtCliente, txtPeso, txtDistancia;
    private JComboBox<String> cmbTipoEnvio;

    public FrmLogistica() {
        setSize(600, 400);
        setTitle("Operador Logísitico");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Barra con iconos (si las imágenes no existen, los botones se quedan sin icono)
        JToolBar tbLogistica = new JToolBar();

        JButton btnAgregarEnvio = new JButton();
        ImageIcon icAgregar = loadIcon("/iconos/AgregarEnvio.png");
        if (icAgregar != null) btnAgregarEnvio.setIcon(icAgregar);
        else btnAgregarEnvio.setText("+");
        btnAgregarEnvio.setToolTipText("Agregar Envío");
        btnAgregarEnvio.addActionListener((ActionEvent evt) -> agregarEnvio());
        tbLogistica.add(btnAgregarEnvio);

        JButton btnQuitarEnvio = new JButton();
        ImageIcon icQuitar = loadIcon("/iconos/QuitarEnvio.png");
        if (icQuitar != null) btnQuitarEnvio.setIcon(icQuitar);
        else btnQuitarEnvio.setText("-");
        btnQuitarEnvio.setToolTipText("Quitar Envío");
        btnQuitarEnvio.addActionListener((ActionEvent evt) -> quitarEnvio());
        tbLogistica.add(btnQuitarEnvio);

        // Contenedor principal de ENVIOS con BoxLayout (vertical)
        JPanel pnlEnvios = new JPanel();
        pnlEnvios.setLayout(new BoxLayout(pnlEnvios, BoxLayout.Y_AXIS));

        // Panel de edición (oculto al inicio) — mismo diseño que tenías
        pnlEditarEnvio = new JPanel();
        pnlEditarEnvio.setPreferredSize(new Dimension(pnlEditarEnvio.getWidth(), 250));
        pnlEditarEnvio.setLayout(null);

        JLabel lblNumero = new JLabel("Número");
        lblNumero.setBounds(10, 10, 100, 25);
        pnlEditarEnvio.add(lblNumero);

        txtNumero = new JTextField();
        txtNumero.setBounds(110, 10, 100, 25);
        pnlEditarEnvio.add(txtNumero);

        JLabel lblCliente = new JLabel("Cliente");
        lblCliente.setBounds(10, 40, 100, 25);
        pnlEditarEnvio.add(lblCliente);

        txtCliente = new JTextField();
        txtCliente.setBounds(110, 40, 200, 25);
        pnlEditarEnvio.add(txtCliente);

        JLabel lblPeso = new JLabel("Peso");
        lblPeso.setBounds(10, 70, 100, 25);
        pnlEditarEnvio.add(lblPeso);

        txtPeso = new JTextField();
        txtPeso.setBounds(110, 70, 100, 25);
        pnlEditarEnvio.add(txtPeso);

        JLabel lblTipo = new JLabel("Tipo");
        lblTipo.setBounds(320, 10, 100, 25);
        pnlEditarEnvio.add(lblTipo);

        cmbTipoEnvio = new JComboBox<>();
        cmbTipoEnvio.setBounds(420, 10, 120, 25);
        String[] opciones = new String[] { "Terrestre", "Aéreo", "Marítimo" };
        DefaultComboBoxModel<String> mdlTipoEnvio = new DefaultComboBoxModel<>(opciones);
        cmbTipoEnvio.setModel(mdlTipoEnvio);
        pnlEditarEnvio.add(cmbTipoEnvio);

        JLabel lblDistancia = new JLabel("Distancia en Km");
        lblDistancia.setBounds(320, 40, 100, 25);
        pnlEditarEnvio.add(lblDistancia);

        txtDistancia = new JTextField();
        txtDistancia.setBounds(420, 40, 120, 25);
        pnlEditarEnvio.add(txtDistancia);

        JButton btnGuardarEnvio = new JButton("Guardar");
        btnGuardarEnvio.setBounds(320, 80, 100, 25);
        btnGuardarEnvio.addActionListener((ActionEvent evt) -> guardarEnvio());
        pnlEditarEnvio.add(btnGuardarEnvio);

        JButton btnCancelarEnvio = new JButton("Cancelar");
        btnCancelarEnvio.setBounds(440, 80, 100, 25);
        btnCancelarEnvio.addActionListener((ActionEvent evt) -> cancelarEnvio());
        pnlEditarEnvio.add(btnCancelarEnvio);

        pnlEditarEnvio.setVisible(false); // oculto al inicio

        // Tabla de envíos
        tblEnvios = new JTable();
        tblEnvios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane spListaEnvios = new JScrollPane(tblEnvios);

        DefaultTableModel dtm = new DefaultTableModel(null, encabezados);
        tblEnvios.setModel(dtm);

        // Agregar componentes al contenedor
        pnlEnvios.add(pnlEditarEnvio);
        pnlEnvios.add(spListaEnvios);

        getContentPane().add(tbLogistica, BorderLayout.NORTH);
        getContentPane().add(pnlEnvios, BorderLayout.CENTER);
    }

    // Crea y retorna Icon desde el recurso; si no existe devuelve null
    private ImageIcon loadIcon(String resourcePath) {
        try {
            URL url = getClass().getResource(resourcePath);
            if (url != null) return new ImageIcon(url);
        } catch (Exception ex) {
            // no hacer nada, retornará null
        }
        return null;
    }

    // Muestra el panel de edición y limpia los campos para un nuevo envío
    public void agregarEnvio() {
        txtNumero.setText("");
        txtCliente.setText("");
        txtPeso.setText("");
        txtDistancia.setText("");
        cmbTipoEnvio.setSelectedIndex(0);
        pnlEditarEnvio.setVisible(true);
        txtNumero.requestFocusInWindow();
    }

    // Elimina la fila seleccionada en la tabla
    public void quitarEnvio() {
        int fila = tblEnvios.getSelectedRow();
        if (fila >= 0) {
            int confirm = JOptionPane.showConfirmDialog(this, "¿Eliminar envío seleccionado?", "Confirmar", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                DefaultTableModel model = (DefaultTableModel) tblEnvios.getModel();
                model.removeRow(fila);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecciona una fila para eliminar.", "Atención", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // Fábrica que crea la subclase correcta según el tipo
    private Envio crearEnvio(String tipo, String codigo, String cliente, double peso, double distancia) {
        switch (tipo) {
            case "Terrestre":
                return new EnvioTerrestre(codigo, cliente, peso, distancia);
            case "Aéreo":
                return new EnvioAereo(codigo, cliente, peso, distancia);
            case "Marítimo":
                return new EnvioMaritimo(codigo, cliente, peso, distancia);
            default:
                throw new IllegalArgumentException("Tipo desconocido: " + tipo);
        }
    }

    // Guarda el envío en la tabla (con validaciones)
    public void guardarEnvio() {
        try {
            String numero = txtNumero.getText().trim();
            String cliente = txtCliente.getText().trim();
            String sPeso = txtPeso.getText().trim().replace(',', '.');
            String sDistancia = txtDistancia.getText().trim().replace(',', '.');

            if (numero.isEmpty() || cliente.isEmpty() || sPeso.isEmpty() || sDistancia.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Rellena todos los campos.", "Atención", JOptionPane.WARNING_MESSAGE);
                return;
            }

            double peso = Double.parseDouble(sPeso);
            double distancia = Double.parseDouble(sDistancia);
            String tipo = (String) cmbTipoEnvio.getSelectedItem();

            Envio envio = crearEnvio(tipo, numero, cliente, peso, distancia);
            double costo = envio.calcularCosto();

            DefaultTableModel model = (DefaultTableModel) tblEnvios.getModel();
            // Mantengo el orden original de columnas: Código, Cliente, Peso, Distancia, Tipo, Costo
            model.addRow(new Object[] {
                envio.getCodigo(),
                envio.getCliente(),
                envio.getPeso(),
                envio.getDistancia(),
                tipo,
                String.format("%.2f", costo)
            });

            // limpiar y ocultar
            cancelarEnvio();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Peso o distancia no son números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al guardar el envío: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Limpia campos y oculta el panel de edición
    public void cancelarEnvio() {
        txtNumero.setText("");
        txtCliente.setText("");
        txtPeso.setText("");
        txtDistancia.setText("");
        cmbTipoEnvio.setSelectedIndex(0);
        pnlEditarEnvio.setVisible(false);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            FrmLogistica f = new FrmLogistica();
            f.setVisible(true);
        });
    }
}


